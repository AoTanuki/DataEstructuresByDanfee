package jar;


import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class principal  implements Initializable{

    @FXML
    private Button addbutton;

    @FXML
    private Button modifybutton;

    @FXML
    private Button deletebutton;

    @FXML
    private Label labelName;

    @FXML
    private Label yearlabel;

    @FXML
    private Label teamlabel;

    @FXML
    private Label gameslabel;

    @FXML
    private Label pointslabel;

    @FXML
    private Label reboundslabel;

    @FXML
    private Label assistslabel;

    @FXML
    private Label robbertieslabel;

    @FXML
    private Label blockslabel;

    @FXML
    private TextField nametext;

    @FXML
    private TextField yeartext;

    @FXML
    private TextField teamtext;

    @FXML
    private TextField gamestext;

    @FXML
    private TextField pointstext;

    @FXML
    private TextField reboundstext;

    @FXML
    private TextField assiststext;

    @FXML
    private TextField robberiestext;

    @FXML
    private TextField blockstext;

    @FXML
    private Button buttonImport;

    @FXML
    private TextField searchpointsbutton;

    @FXML
    private TextField searchReboundsButton;

    @FXML
    private TextField SearchAssistsButton;

    @FXML
    private TextField searchRobberiesButton;

    @FXML
    private TextField searchBlocksButton;

    @FXML
    private Button buttonSearch;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		labelName.setText("Hello");
	//	labelName.setEnabled(false);
	}

}
