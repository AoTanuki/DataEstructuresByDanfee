package jar;


import java.net.URL;
import java.util.ResourceBundle;

import com.sun.javafx.menu.RadioMenuItemBase;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class principal  implements Initializable{
	
	
	
	   

        @FXML
        private RadioButton noBalance;


	   @FXML
	    private Button buttonImport;

	    @FXML
	    private ComboBox<String> choose;

	    @FXML
	    private Label initialValueLabel;

	    @FXML
	    private TextField valueInitial;

	    @FXML
	    private TextField finalValue;
	    

	    @FXML
	    private RadioButton defatree;

	    @FXML
	    private Label finalValueLabel;

	    @FXML
	    private RadioButton range;

	    @FXML
	    private RadioButton noRange;

	    @FXML
	    private Label labelName1;

	    @FXML
	    private Label genderlabel1;

	    @FXML
	    private Label agelabel1;

	    @FXML
	    private Label gameslabel1;

	    @FXML
	    private Label minuteslabel1;

	    @FXML
	    private Label FieldGoalslabel1;

	    @FXML
	    private Label ThreePointslabel1;

	    @FXML
	    private Label Personallabel1;

	    @FXML
	    private Label PlayerImpactlabel1;

	    @FXML
	    private TextField nametext1;

	    @FXML
	    private TextField gendertext1;

	    @FXML
	    private TextField Agetext1;

	    @FXML
	    private TextField gamestext1;

	    @FXML
	    private TextField Minutestext1;

	    @FXML
	    private TextField FieldGoalstext1;

	    @FXML
	    private TextField ThreePointstext1;

	    @FXML
	    private TextField PersonalFoulstext1;

	    @FXML
	    private TextField PLayerImpacttext1;

	    @FXML
	    private Label offensiveLabel1;

	    @FXML
	    private Label TurnOverlabel111;

	    @FXML
	    private TextField Offensivetext1;

	    @FXML
	    private TextField TurnOverText1;

	    @FXML
	    private Button addbutton;

	    @FXML
	    private Button modifybutton;

	    @FXML
	    private Button deletebutton;

	    @FXML
	    private Button buttonSearch;
	
	    @FXML
	    private Label value;

	    @FXML
	    private TextField valuetext;
    
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		choose.getItems().add("FIELD GOALS PERCENTAGE");
		choose.getItems().add("THREE POINT FIELD GOALS PERCENTAGE");
		choose.getItems().add("FREE THROW PERCENTAGE");
		choose.getItems().add("PERSONAL FOULS");
		
	    choose.setValue("FIELD GOALS PERCENTAGE");
	    value.setVisible(false);
	    valuetext.setVisible(false);
	    
	    
	    
		
		initialValueLabel.setVisible(false);
		finalValueLabel.setVisible(false);
		valueInitial.setVisible(false);
		finalValue.setVisible(false);
		
		

	}
	
	 @FXML
	    void accion(ActionEvent event) {
		 
	     noRange.setSelected(false);
		 
		 initialValueLabel.setVisible(true);
		 valueInitial.setVisible(true);
		 finalValueLabel.setVisible(true);
		 finalValue.setVisible(true);
		   value.setVisible(false);
		    valuetext.setVisible(false);
	 }
	 
	 @FXML
	    void accionNoRange(ActionEvent event) {
		 range.setSelected(false);

		 initialValueLabel.setVisible(false);
		 valueInitial.setVisible(false);
		 finalValueLabel.setVisible(false);
		 finalValue.setVisible(false);
		   value.setVisible(true);
		    valuetext.setVisible(true);
		 
	    }
	 
	 
	 @FXML
	    void searchList(ActionEvent event) {
		 

	    }
	 
	 @FXML
	    void NoBalanceTreeaction(ActionEvent event) {
		 
		 
			 defatree.setSelected(false);
		 

	    }
	 
	 @FXML
	    void defaultAction(ActionEvent event) {
		 
		    noBalance.setSelected(false);

	    }

}
